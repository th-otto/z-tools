#include "ilbm.h"

LONG ifferr( LONG err ) {
	if ( err < 0 ) {
		switch( err ) {
			case IFFERR_NOTIFF:
				err = RC_NOT_IFF;
				break;
			case IFFERR_READ:
			case IFFERR_WRITE:
			case IFFERR_SEEK:
				err = RC_RW_ERROR;
				break;
			case IFFERR_MANGLED:
			case IFFERR_SYNTAX:
			case IFFERR_NOSCOPE:
				err = RC_CORRUPT_IFF;
				break;
			case IFFERR_NOMEM:
				err = RC_NO_MEM;
				break;
			default:
				err = RC_FAILED;
		}
	}
	return( err );
}

LONG loadilbm( struct ILBMInfo *ilbm, UBYTE *filename ) {

	struct IFFHandle	*iff;
	LONG	error;

	iff = ilbm->iff;

	if ( !( iff->iff_Stream = Open( filename, MODE_OLDFILE )))
		return( RC_NO_FILE );

	InitIFFasDOS( iff );

	if ( !( error = OpenIFF( iff, IFFF_READ ))) {
		if ( PropChunk( iff, ID_ILBM, ID_BMHD )||
			PropChunk( iff, ID_ILBM, ID_CMAP )||
			PropChunk( iff, ID_ILBM, ID_CAMG )||
			StopChunk( iff, ID_ILBM, ID_BODY ))
			    return( ifferr( RC_NO_MEM ));

		error = ParseIFF( iff, IFFPARSE_SCAN );

		if (( !error )||( error == IFFERR_EOC )||( error == IFFERR_EOF )) {
			if ( !( error = getbitmap( ilbm ) ))
				error = getcolors( ilbm );
			if ( !error )
				error = loadbody( ilbm );
		}
	}
    return( ifferr( error ));
}

void unloadilbm(struct ILBMInfo *ilbm) {

	struct IFFHandle *iff;
	struct BitMap	*bmp;
	int	i;

	bmp = &ilbm->bitmap;
	for ( i=0; i < bmp->Depth; i++ ) {
		if ( bmp->Planes[i] )
			FreeVec( bmp->Planes[i] );
	}

	if ( !( iff = ilbm->iff ))
		return;

	if ( iff->iff_Stream ) {
		CloseIFF( iff );
		Close( iff->iff_Stream );
	}

	iff->iff_Stream = NULL;
}

LONG getbitmap(struct ILBMInfo *ilbm) {

	struct IFFHandle		*iff;
	struct StoredProperty	*sp;
	UWORD	sw, sh;
	LONG  	error = RC_OK;
	int		i;
	BYTE	np;

	iff = ilbm->iff;

	if ( !( sp = FindProp( iff, ID_ILBM, ID_BMHD )))
		return( RC_NOT_ILBM );

	*(&ilbm->bmhd) = *((BitMapHeader *) sp->sp_Data);	/* copy contents of BMHD */

	sw = RowBits( ilbm->bmhd.w ); //allign to 16
	sh = ilbm->bmhd.h;
	np = ilbm->bmhd.nPlanes;

	if (( sw<32*8 )||( sh<2 )||( np>4 ))
		return( RC_NOT_DCTV );

	if (( ilbm->bmhd.masking == mskHasMask )||( ilbm->bmhd.masking == mskHasAlpha ))
		return( RC_NOT_SUPPORT );

	if (( ilbm->bmhd.compression > cmpByteRun1 ))
		return( RC_NOT_SUPPORT );

	if ( sp = FindProp( iff, ID_ILBM, ID_CAMG )) {
		ilbm->camg = (* (ULONG *) sp->sp_Data) & SUPERLACE_KEY;
	} else {
		ilbm->camg = 0;
		if ( ilbm->bmhd.pageWidth >= 640 )
			ilbm->camg = HIRES;
		if ( ilbm->bmhd.pageHeight >= 400 )
			ilbm->camg |= LACE;
	}

	ilbm->bitmap.BytesPerRow = sw >> 3;
	ilbm->bitmap.Rows = sh;
	ilbm->bitmap.Depth = np;
	for ( i=0; i<np && (!error); i++ ) {
		if ( !( ilbm->bitmap.Planes[i] = AllocVec( (sw>>3)*sh, MEMF_CLEAR ) ))
			error = RC_NO_MEM;
	}

	return( error );
}

LONG getcolors( struct ILBMInfo *ilbm ) {

	struct	StoredProperty	*sp;
	LONG	error = RC_OK;
	USHORT	ncolors, i;
	UBYTE	*rgb;
	ULONG	r, g, b;

	if ( sp = FindProp( ilbm->iff, ID_ILBM, ID_CMAP )) {
		ncolors = sp->sp_Size / 3;		/* how many in CMAP */
		if ( ncolors >= ( 1 << ilbm->bitmap.Depth )) {
			rgb = sp->sp_Data;
			i = 0;
			while ( ncolors-- ) {
				r = (*rgb++ & 0xF0) << 4;
				g = *rgb++ & 0xF0;
				b = *rgb++ >> 4;
				ilbm->colortable[i++] = r | g | b;
			}
		} else {
			error = RC_NOT_SUPPORT;
		}
	} else {
		error = RC_NOT_SUPPORT;
	}
	return(error);
}

LONG loadbody( struct ILBMInfo *ilbm) {

	struct IFFHandle	*iff;
	struct ContextNode	*cn;
	BYTE	*buffer;
	ULONG	bufsize;
	LONG	error;

	iff = ilbm->iff;
	if ( cn = CurrentChunk( iff ) ) {
		if (( cn->cn_Type == ID_ILBM )&&( cn->cn_ID == ID_BODY )) {
			bufsize = cn->cn_Size;
			if ( buffer = AllocVec( bufsize, MEMF_ANY )) {
				if ( ReadChunkBytes( iff, buffer, bufsize ) == bufsize ) {
					error = decodeilbm( ilbm, buffer, bufsize );
				} else {
					error = IFFERR_READ;
				}
				FreeVec( buffer );
			} else {
				error = IFFERR_NOMEM;
			}
		} else {
			error = RC_NOT_ILBM;	// eg. palette
		}
	} else {
		error = IFFERR_MANGLED;
	}
	return(error);
}

LONG decodeilbm( struct ILBMInfo *ilbm, BYTE *buffer, ULONG bufsize ) {

	UBYTE	np;
	UWORD	bpr, sh ,cmp;
	WORD	i, j;
	LONG	len;
	BYTE	*buf, *plane[4];

	np = ilbm->bitmap.Depth;
	bpr = ilbm->bitmap.BytesPerRow;
	sh = ilbm->bitmap.Rows;
	cmp = ilbm->bmhd.compression;
	for ( i = 0; i < np; i++)
		plane[i] = ilbm->bitmap.Planes[i];

	if ( !cmp )	{	// cmpNone
		if ( bufsize < bpr * sh * np )
			return( IFFERR_MANGLED );
	}

	for ( i = sh; i > 0; i--) {
		for ( j = 0; j < np; j++) {
			buf = plane[j];
			if ( !cmp ) {	// cmpNone
				CopyMem( buffer, buf, bpr);
				buffer += bpr;
				buf += bpr;
			} else {
				if ( bufsize <= 0 )
					return( IFFERR_MANGLED );
				if ( !( len = unpackrow( buffer, buf, bufsize, bpr )))
					return( IFFERR_MANGLED );
				buffer += len;
				bufsize -= len;
				buf += bpr;
			}
			plane[j] = buf;
		}
	}
	return( RC_OK );
}
