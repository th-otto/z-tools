#include "ilbm.h"

void ConvertDCTVLine(struct DCTVCvtHandle *cvt);

BOOL CheckDCTV( struct BitMap *bmp );
void SetmapDCTV( struct DCTVCvtHandle *cvt, UWORD *cmap );

struct DCTVCvtHandle* AllocDCTV( struct BitMap *bmp, UWORD lace );

/* asm funcktions */
void __asm p2c( register __a0 UBYTE *chunky, register __a1 struct BitMap *bmp, register __d0 UWORD line );

struct DCTVCvtHandle {
	UBYTE	*Red, *Green, *Blue, *Chunky;
	struct BitMap	*BitMap;
	UWORD	Width, Height;
	UBYTE	Depth, Lace;
	WORD	LineNum;
	UBYTE	Palette[16];
	UBYTE	*FBuf1[3], *FBuf2[3];
	// private data follows (10*width)
	// width bytes of Red
	// width bytes of Green
	// width bytes of Blue
	// width bytes of Chunky
	// 3*width bytes of luma/chroma (first field)
	// 3*width bytes of luma/chroma (second field)
};
