#include "ilbm.h"
#include "dctv.h"

const char version[] = "$VER: dctv24 1.3 " __AMIGADATE__ " by Cholok";

//Error messages
static UBYTE *dctv_Error[] = {
	"",
	"can't open file",
	"read/write error",
	"out of memory",
	"can't open iffparse.library",
	"not an IFF file",
	"not an IFF-ILBM picture",
	"not a DCTV picture",
	"IFF file is corrupted",
	"this ILBM is not supported",
	"operation failed"
};

void __regargs __chkabort(void) { }	//Disable SASC CTRL/C handling

LONG Convert( void );
BOOL WriteChunkyLine24( struct IFFHandle *iff, struct DCTVCvtHandle	*cvt );
void __asm c2p( register __a0 UBYTE *chunky, register __a1 UBYTE **planes, register __d0 UWORD width );

extern struct ExecBase	*SysBase;
struct Library 			*IFFParseBase = NULL;
struct ILBMInfo	ilbm = {0};
LONG	opts[2];
UBYTE	*infile;
UBYTE	*outfile;
UBYTE	*plane = NULL;
BYTE	*compressed = NULL;

void main( int argc, char **argv ) {

	LONG	error = RC_OK;
	struct RDArgs	*rdargs;

	//from icon
	if ( !argc )
		exit( RETURN_ERROR );
	
	if ( SysBase->LibNode.lib_Version < 36 ) {
		puts("Kickstart V36 at least required");
		exit( RETURN_FAIL );
	}

	if ( !( SysBase->AttnFlags & AFF_68020 )) {
		puts("CPU020 at least required");
		exit( RETURN_FAIL );
	}

	if ( !(rdargs = ReadArgs( "DCTV/A,IFF24/A", opts, NULL ))) {
		PrintFault( IoErr(), NULL );
		exit( RETURN_ERROR );
	}

	infile = (UBYTE *) opts[0];
	outfile = (UBYTE *) opts[1];
	
	if ( ( IFFParseBase = OpenLibrary("iffparse.library",0) )) {
		if( ( ilbm.iff = AllocIFF())) {
			if ( !(error = loadilbm( &ilbm, infile ))) {
				error = Convert();
			}
			unloadilbm( &ilbm );
			FreeIFF( ilbm.iff );
		} else error = RC_NO_MEM;
		CloseLibrary( IFFParseBase );
	} else error = RC_NO_IFFLIB;
	
	if ( rdargs )
		FreeArgs( rdargs );

	if ( error ) {
		printf("%ls\n",dctv_Error[error]);
		error = RETURN_FAIL;
	}

	exit( error );
}

/* Convert to 24 bit */
LONG Convert() {

	struct IFFHandle		*iff24;
	struct DCTVCvtHandle	*cvt;
	WORD	i, sw;
	LONG	error;

	if ( !( CheckDCTV( &ilbm.bitmap )) )
		return( RC_NOT_DCTV );

	cvt = AllocDCTV( &ilbm.bitmap, (ilbm.camg & LACE) ? 1 : 0 );
	plane = AllocVec( ilbm.bitmap.BytesPerRow << 3, MEMF_ANY );
	compressed = AllocVec( MaxPackedSize( ilbm.bitmap.BytesPerRow ), MEMF_ANY );

	if (( !cvt )||( !plane )||( !compressed )) {
		FreeVec( compressed );	//FreeVec(NULL) is ok
		FreeVec( plane );
		FreeVec( cvt );
		return( RC_NO_MEM );
	}

	if ( iff24 = AllocIFF() ) {
		if ( iff24->iff_Stream = Open( outfile, MODE_NEWFILE )) {
			InitIFFasDOS( iff24 );
			if ( !( error = OpenIFF( iff24, IFFF_WRITE ))) {
				error = RC_RW_ERROR;
				if ( !( PushChunk( iff24, ID_ILBM, ID_FORM, IFFSIZE_UNKNOWN )))
					if ( !( PushChunk( iff24, ID_ILBM, ID_BMHD, sizeof( BitMapHeader ) ))) {
						// use BMHD from source pic
						ilbm.bmhd.nPlanes=24;
						ilbm.bmhd.masking=mskNone;
						ilbm.bmhd.compression=cmpByteRun1;
						ilbm.bmhd.flags=0;
						if ( WriteChunkBytes( iff24, &ilbm.bmhd, sizeof( BitMapHeader )) == sizeof( BitMapHeader ))
							if ( !( PopChunk( iff24 )))
								if ( !(PushChunk( iff24, ID_ILBM, ID_BODY, IFFSIZE_UNKNOWN )))
									error = RC_OK;
					}
			}
		} else error = RC_RW_ERROR;
	} else error = RC_NO_MEM;

	// convert loop
	if ( !error ) {
		SetmapDCTV( cvt, ilbm.colortable );
		sw = cvt->Width;
		for ( i=0; i<cvt->Height; i++ ) {
			if ( SetSignal( 0,SIGBREAKF_CTRL_C ) & SIGBREAKF_CTRL_C ) {
				puts("**BREAK");
				break;
			}
			ConvertDCTVLine( cvt );
			if ( !WriteChunkyLine24( iff24, cvt )) {
				error = RC_RW_ERROR;
				break;
			}
		}
	}

	// close BODY, FORM
	if ( !error ) {
		if ( !( PopChunk( iff24 ))) {
			if ( PopChunk( iff24 ))
				error = RC_RW_ERROR;
		} else error = RC_RW_ERROR;
	}

	FreeVec( compressed );
	FreeVec( plane );
	FreeVec( cvt );
	if ( iff24 ) {
		CloseIFF( iff24 );
		if ( iff24->iff_Stream )
			Close( iff24->iff_Stream );
		FreeIFF( iff24 );
	}
	return( error );
}

/* Write one line of a 24-bit color */
BOOL WriteChunkyLine24( struct IFFHandle *iff, struct DCTVCvtHandle	*cvt ) {
	UBYTE	i;
	UWORD	bpr, sw;
	LONG	length;
	UBYTE	*bpl[8];

	sw = cvt->Width;
	bpr =  sw >> 3;

	for( i=0; i<8; i++ )
		bpl[i] = plane + i * bpr;
	c2p( cvt->Red, bpl, sw );	//*bpl[] are modified
	for( i=0; i<8; i++ ) {
		length = packrow( plane + i * bpr, compressed, bpr );
		if ( WriteChunkBytes( iff, compressed, length) != length )
	  		return FALSE;
	}

	for( i=0; i<8; i++ )
		bpl[i] = plane + i * bpr;
	c2p( cvt->Green, bpl, sw );	//*bpl[] are modified
	for( i=0; i<8; i++ ) {
		length = packrow( plane + i * bpr, compressed, bpr );
		if ( WriteChunkBytes( iff, compressed, length) != length )
	  		return FALSE;
	}

	for( i=0; i<8; i++ )
		bpl[i] = plane + i * bpr;
	c2p( cvt->Blue, bpl, sw );	//*bpl[] are modified
	for( i=0; i<8; i++ ) {
		length = packrow( plane + i * bpr, compressed, bpr );
		if ( WriteChunkBytes( iff, compressed, length) != length )
	  		return FALSE;
	}

	return TRUE;
}
