#ifndef IFFP_ILBM_H
#define IFFP_ILBM_H

#include <exec/memory.h>
#include <exec/execbase.h>
#include <proto/exec.h>
#include <proto/graphics.h>
#include <proto/dos.h>
#include <proto/iffparse.h>
#include <math.h>
#include <stdio.h>
#include <stdlib.h>

// return codes
#define RC_OK			0
#define RC_NO_FILE		1
#define RC_RW_ERROR		2
#define RC_NO_MEM		3
#define RC_NO_IFFLIB	4
#define RC_NOT_IFF		5
#define RC_NOT_ILBM		6
#define RC_NOT_DCTV		7
#define RC_CORRUPT_IFF	8
#define RC_NOT_SUPPORT	9
#define RC_FAILED		10

/* IFF types we may encounter */
#define	ID_ILBM		MAKE_ID('I','L','B','M')
#define	ID_BMHD		MAKE_ID('B','M','H','D')
#define	ID_CMAP		MAKE_ID('C','M','A','P')
#define	ID_CAMG		MAKE_ID('C','A','M','G')
#define ID_BODY		MAKE_ID('B','O','D','Y')

#define MaxPackedSize(rowSize)  ( (rowSize) + ( ((rowSize)+127) >> 7 ) )
#define RowBytes(w)	((((w) + 15) >> 4) << 1)
#define RowBits(w)	((((w) + 15) >> 4) << 4)

/* Masking techniques */
#define	mskNone					0
#define	mskHasMask				1
#define	mskHasTransparentColor	2
#define	mskLasso				3
#define	mskHasAlpha				4

/* Compression techniques */
#define	cmpNone			0
#define	cmpByteRun1		1

/* BMHD structure */
typedef struct {
	UWORD	w, h;
	WORD	x, y;
	UBYTE	nPlanes, masking;
	UBYTE	compression, flags;
	UWORD	transparentColor;
	UBYTE	xAspect, yAspect;
	WORD	pageWidth, pageHeight;
} BitMapHeader;

struct ILBMInfo {
	struct IFFHandle 	*iff;
	struct BitMap 	bitmap;
	BitMapHeader	bmhd;
	ULONG			camg;
	UWORD			colortable[16];
};

LONG __asm unpackrow( APTR register __a0, APTR register __a1, LONG register __d0, LONG register __d1 );
LONG __asm packrow( APTR register __a0, APTR register __a1, LONG register __d0 );

LONG loadbody(struct ILBMInfo *ilbm);
LONG decodeilbm(struct ILBMInfo *ilbm, BYTE *buffer, ULONG bufsize);
LONG getcolors(struct ILBMInfo *ilbm);
LONG getbitmap(struct ILBMInfo *ilbm);

LONG loadilbm(struct ILBMInfo *ilbm, UBYTE *filename);
void unloadilbm(struct ILBMInfo *ilbm);

#endif /* IFFP_ILBM_H */
