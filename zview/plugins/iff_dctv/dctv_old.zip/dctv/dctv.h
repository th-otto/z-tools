#include "ilbm.h"

void luma( UBYTE *lbuf, UWORD sw, UWORD zzflag );
void chroma( UBYTE *lbuf, UWORD sw, UWORD zzflag );
void yuv2rgb( UBYTE *lbuf, BYTE *ch1buf, BYTE *ch2buf, struct DCTVCvtHandle *cvt );
void filter( UBYTE *rgbbuf, UWORD sw );
void pal2direct( struct DCTVCvtHandle *cvt );
void join( UBYTE *chunky, UBYTE *lbuf, UWORD sw, UWORD zzflag );
void dc2rgb( struct DCTVCvtHandle *cvt, UWORD srcline );
void blank( struct DCTVCvtHandle *cvt, UWORD offset, UWORD size );

void ConvertDCTVLine(struct DCTVCvtHandle *cvt);

BOOL CheckDCTV( struct BitMap *bmp );
void SetmapDCTV( struct DCTVCvtHandle *cvt, UWORD *cmap );

struct DCTVCvtHandle* AllocDCTV( struct BitMap *bmp, UWORD lace );

/* asm funcktions */
void __asm p2c( register __a0 UBYTE *chunky, register __a1 struct BitMap *bmp, register __d0 UWORD line );

struct DCTVCvtHandle {
	UBYTE	*Red, *Green, *Blue, *Chunky;
	struct BitMap	*BitMap;
	UWORD	Width, Height;
	UWORD	*ColorTable;
	UBYTE	NColors, Lace;
	WORD	LineNum;
	UBYTE	*FBuf1[4], *FBuf2[4];
	UBYTE	Palette[16];
	// private data follows (16*width)
	// width bytes of Red
	// width bytes of Green
	// width bytes of Blue
	// width bytes of Chunky
	// 4*1.5*width bytes of luma/chroma (4 lines, first field)
	// 4*1.5*width bytes of luma/chroma (4 lines, second field)
};
