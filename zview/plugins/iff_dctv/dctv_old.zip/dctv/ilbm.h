#ifndef IFFP_ILBM_H
#define IFFP_ILBM_H

#include <exec/memory.h>
#include <exec/execbase.h>
#include <proto/exec.h>
#include <proto/graphics.h>
#include <proto/dos.h>
#include <proto/iffparse.h>
#include <math.h>
#include <stdio.h>
#include <stdlib.h>

/* IFF types we may encounter */
#define	ID_ILBM		MAKE_ID('I','L','B','M')
#define	ID_BMHD		MAKE_ID('B','M','H','D')
#define	ID_CMAP		MAKE_ID('C','M','A','P')
#define	ID_CAMG		MAKE_ID('C','A','M','G')
#define ID_BODY		MAKE_ID('B','O','D','Y')

#define MaxPackedSize(rowSize)  ( (rowSize) + ( ((rowSize)+127) >> 7 ) )
#define RowBytes(w)	((((w) + 15) >> 4) << 1)
#define RowBits(w)	((((w) + 15) >> 4) << 4)

/* Masking techniques */
#define	mskNone					0
#define	mskHasMask				1
#define	mskHasTransparentColor	2
#define	mskLasso				3
#define	mskHasAlpha				4

/* Compression techniques */
#define	cmpNone			0
#define	cmpByteRun1		1

/* BMHD structure */
typedef struct {
	UWORD	w, h;
	WORD	x, y;
	UBYTE	nPlanes, masking;
	UBYTE	compression, flags;
	UWORD	transparentColor;
	UBYTE	xAspect, yAspect;
	WORD	pageWidth, pageHeight;
} BitMapHeader;

struct ILBMInfo {
	struct IFFHandle 	*iff;
	struct BitMap 	bitmap;
	BitMapHeader	bmhd;
	ULONG			camg;
	UWORD			colortable[16];
};

BOOL unpackrow(BYTE **pSource, BYTE **pDest, LONG srcBytes0, WORD dstBytes0);
LONG packrow(BYTE **pSource, BYTE **pDest, LONG rowSize);

LONG loadbody(struct ILBMInfo *ilbm);
LONG decodeilbm(struct ILBMInfo *ilbm, BYTE *buffer, ULONG bufsize);
LONG getcolors(struct ILBMInfo *ilbm);
LONG getbitmap(struct ILBMInfo *ilbm);

LONG loadilbm(struct ILBMInfo *ilbm, UBYTE *filename);
void unloadilbm(struct ILBMInfo *ilbm);

#endif /* IFFP_ILBM_H */
