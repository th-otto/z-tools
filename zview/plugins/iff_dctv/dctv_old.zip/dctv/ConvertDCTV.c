#include "dctv.h"
#include "dctvtabs.h"

void pal2direct( struct DCTVCvtHandle *cvt ) {

	WORD	cnt;
	UBYTE	*buf;

	cnt = cvt->Width;
	buf = cvt->Chunky;

	while ( cnt>0 ) {
		*buf = cvt->Palette[*buf];	//pixel=palette[pixel]
		*buf++;
		cnt--;
	}
}

void join( UBYTE *chunky, UBYTE *lbuf, UWORD sw, UWORD zzflag ) {

	UWORD	cnt;
	UBYTE	pix;

	cnt = ( sw >> 1 ) - 1 - zzflag;
	chunky = chunky + zzflag + 1;
	lbuf = lbuf + 2 * ( zzflag + 1 );

	// read chunkybuf
	// $0054xxyy...zz0000
	// $14xxyy.......zz00
	// write lbuf (composite)
	// $40404040xxxx...zz
	// $4040xxxx.......zz

	while ( cnt>0 ) {
		pix = *chunky++;	//%0x0x0x0x (4 bit value)
		pix <<= 1;
		pix |= *chunky++;	//%xyxyxyxy (8 bit value)
		if ( !pix )
			pix = 0x40;	//luma=0
		*lbuf++ = pix;
		*lbuf++ = pix;	//store 2 8-bit pixels
		cnt--;
	}
}

void filter( UBYTE *rgbbuf, UWORD sw ) {

	WORD	cnt;
	UBYTE	d1, d2, d3, *buf;

	cnt = sw - 2;
	buf = rgbbuf + 3;

	d2 = rgbbuf[1];
	d3 = rgbbuf[2];

	while ( cnt>0 ) {
		d1 = d2;
		d2 = d3;
		d3 = *buf++;
		*rgbbuf++ = ( d1 + d2 + d2 + d3 ) >> 2;
		cnt--;
	}

	*rgbbuf++ = ( d2 + d3 + d3 ) >> 2;
	*rgbbuf = d3 >> 1;
}

WORD minmax( WORD pix, WORD min, WORD max ) {

	if ( pix < min )
		pix = min;
	else if ( pix > max )
		pix = max;

	return pix;
}

void yuv2rgb( UBYTE *lbuf, BYTE *ch1buf, BYTE *ch2buf, struct DCTVCvtHandle *cvt ) {

	WORD	cnt, d0, prevchr1, prevchr2, luma, chroma1, chroma2;
	UBYTE	*rbuf, *gbuf, *bbuf;

	cnt = cvt->Width - 1;
	rbuf = cvt->Red;
	gbuf = cvt->Green;
	bbuf = cvt->Blue;

	prevchr1 = *ch1buf++;
	prevchr2 = 0;

	while ( cnt>=0 ) {

		if ( cnt & 1 ) {
			d0 = *ch2buf++;	//chroma2
			chroma1 = prevchr1;
			chroma2 = ( d0 + prevchr2 ) >> 1;
			prevchr2 = d0;
		} else {
			if ( cnt )
				d0 = *ch1buf++;	//chroma1
			else		
				d0 = 0;
			chroma2 = prevchr2;
			chroma1 = ( d0 + prevchr1 ) >> 1;
			prevchr1 = d0;
		}

		luma = (WORD) tables[*lbuf++];

		d0 = (WORD) tables[chroma1+0x180] + luma;
		*rbuf++ = minmax( d0 >> 4, 0 ,255 );

		d0 = (WORD) tables[chroma1+0x380] + (WORD) tables[chroma2+0x480] + luma;
		*gbuf++ = minmax( d0 >> 4, 0 ,255 );

		d0 = (WORD) tables[chroma2+0x280] + luma;
		*bbuf++ = minmax( d0 >> 4, 0, 255 );

		cnt--;
	}
}

void chroma( UBYTE *lbuf, UWORD sw, UWORD zzflag ) {

	WORD	cnt, d0 ,d1 ,d2, d3;
	BYTE	*chrbuf, sign = 0;

	chrbuf = lbuf + sw + 1;	//chromabuf+1
	lbuf = lbuf + zzflag + 1; //lumabuf+1+zzflag

	// $0054...	cnt=(sw-2-4)/2+2=sw/2-1=sw/2-2+zzflag
	// $1400...	cnt=(sw-4)/2    =sw/2-2=sw/2-2+zzflag
	cnt = ( sw >> 1 ) - 2 + zzflag;

	d3 = *lbuf;
	d2 = ( d3 + 64 ) >> 1;

	while ( cnt>0 ) {
		d1 = d2;
		d2 = d3;

		lbuf += 2;
		d3 = *lbuf;	//get composite

		if ( ( d0 = d2 + d2 - d1 - d3 + 2 ) < 0 )
			d0 += 3;

		d0 >>= 2;

		if ( sign ^= 1 )
			d0 = -d0;

		*chrbuf++ = (BYTE) minmax( d0, -127, 127 );

		cnt--;
	}
	// read compbuf
	// $0000xx00yy.....00zz		;bug?, read chromabuf[0]
	// $00xx00yy...zz0000
	// write chromabuf
	// $00xxyy.....zz
	// $00xxyy...zz00
}

void luma( UBYTE *lbuf, UWORD sw, UWORD zzflag ) {

	WORD	cnt, d0, d1, d4;
	WORD	var1,var2,var3,var4,var5,var6,var7;
	BYTE	*chrbuf, *buf, sign;

	buf = lbuf + sw;	//preserved for later

	chrbuf = lbuf + sw + 1;	//chromabuf+1
	lbuf = lbuf + zzflag + 1; //lumabuf+1+zzflag

	// $0054...	cnt=(sw-2-4)/2+2=sw/2-1=sw/2-2+zzflag (-1)
	// $1400...	cnt=(sw-4)/2    =sw/2-2=sw/2-2+zzflag (-1)
	cnt = ( sw >> 1 ) - 2 + zzflag - 1;
	sign = 1;

	var5 = *chrbuf++;
	var6 = *chrbuf++;
	var7 = *chrbuf++;
	d4 = ( var5 + var6 + var7 + 4 );
	var1 = var2 = var3 = var4 = 0;

	if ( !zzflag ) {
		sign = 0;
		var4 = var5;
		var5 = var6;
		var6 = var7;
		var7 = *chrbuf++;
		d4 = d4 + var7 + var4;
		d0 = *lbuf + ( d4 >> 3 );
		d0 = d0 + d0 - 64;
		d1 = minmax( d0, 64, 224 );
		d0 -= d1;
		if ( d0 ) {
			d0 <<= 2;
			d0 += var4;
			d0 = minmax( d0, -127, 127 );
			d4 = d4 - var4 - var4 + d0 + d0;
			chrbuf[-4] = d0;
			var4 = d0;
		}

		*lbuf++ = 64;
		*lbuf++ = d1;
	}

	while ( cnt>0 ) {
		d0 = d4 - var1 - var4;

		var1 = var2;
		var2 = var3;
		var3 = var4;
		var4 = var5;
		var5 = var6;
		var6 = var7;

		var7 = 0;
		if ( cnt >= zzflag + 3 )
			var7 = *chrbuf++;

		d4 = d0 + var7 + var4;
		d0 = d4 >> 3;

		if ( !(	sign ^= 1 ))
			d0 = -d0;

		d1 = minmax( *lbuf - d0, 64, 224 );	//bug?, was 255?

		*lbuf++ = d1;
		*lbuf++ = d1;

		cnt--;
	}

	if ( zzflag ) {
		lbuf[0] = 64;
		lbuf[1] = 64;
	} else {

		d1 = ( d4 -  var1 - var4 + var5 ) >> 3;

		if ( sign )
			d1 = -d1;

		d1 = *lbuf - d1;
		d0 = minmax( d1, 64, 224 );

		d1 -= d0;
		if ( d1 ) {
			d1 <<= 2;
			chrbuf[-1] = (BYTE) var5 - d1;
		}

		*lbuf++ = d0;
		*lbuf++ = 64;
	}

	chrbuf = buf;
	d0 = chrbuf - lbuf;
	if ( d0 > 0 ) {
		d0 -= 1;
		while ( d0 >= 0 ) {
			*lbuf++ = 64;
			d0--;
		}

	}
	*chrbuf++ = 0;

	if ( zzflag )
		chrbuf[0] = chrbuf[1];

	chrbuf = buf + (sw >> 1) - 1;	// last chroma ptr
	d0 = *chrbuf;
	if ( d0 < 0 )
		d0 += 1;
	d0 >>= 1;
	*chrbuf = d0;
}

void dc2rgb( struct DCTVCvtHandle *cvt, UWORD linenr ) {

	UBYTE	*lbuf, *pbuf;
	BYTE	*ch1buf, *ch2buf;
	UWORD	sw;
	ULONG	field, zzflag;

	/* plannar to chunky */
	p2c( cvt->Chunky, cvt->BitMap, linenr );

	/* palette to direct value */
	pal2direct( cvt );

	sw = cvt->Width;

	if ( cvt->Lace ) {
		field = ( linenr + 1 ) & 1;
		linenr >>= 1;
	} else {
		field = 0;
	}

	if ( !field ) {
		lbuf = cvt->FBuf1[linenr & 3];
		pbuf = cvt->FBuf1[(linenr-1) & 3];
	} else {
		lbuf = cvt->FBuf2[linenr & 3];
		pbuf = cvt->FBuf2[(linenr-1) & 3];
	}

	/* find zigzag flag, value 0 or 1 */
	/* (grabbed dctvpaint does not have the zigzag!!! */
	/* no zigzag = no chroma ?) */

	// noninterlaced zigzag (or interlaced field)
	// line1	$0054..., sometimes $xx54 zzflag=1
	// line2	$1400...				  zzflag=0

	if ( cvt->Chunky[1] == 0x54 )
		zzflag = 1;
	else
		zzflag = 0;

	/* join two 4-bit pixels into one 8-bit */
	join( cvt->Chunky, lbuf, sw, zzflag );

	/* decode chroma */
	chroma( lbuf, sw, zzflag );

	/* decode luma */
	luma( lbuf, sw, zzflag );

	/* convert yuv to rgb */
	ch1buf = pbuf + sw;
	ch2buf = lbuf + sw;
	if ( zzflag ) {
		yuv2rgb( lbuf, ch2buf, ch1buf, cvt );
	} else {
		yuv2rgb( lbuf, ch1buf, ch2buf, cvt );
	}

	/* filtering for remove artefacts */
	filter( cvt->Red, sw );
	filter( cvt->Green, sw );
	filter( cvt->Blue, sw );
}

void blank( struct DCTVCvtHandle *cvt, UWORD offset, UWORD size ) {

	BYTE	*red, *green, *blue;

	red = cvt->Red + offset;
	green = cvt->Green + offset;
	blue = cvt->Blue + offset;

	while ( size>0 ) {
		*red++ = 0;
		*green++ = 0;
		*blue++ = 0;
		size--;
	}
}

/*	Convert one line of DCTV image to 24-bit RGB.
	Zigzag column must be first column in the DCTV image
	(dctv.lib looking for nonzero values, we don't).
*/
void ConvertDCTVLine(struct DCTVCvtHandle *cvt) {

	UWORD	line;

	line = cvt->LineNum;	// from 0 to sh-1

	// first line or two (lace) is signature
	if (( line > cvt->Lace )&&( line < cvt->Height )) {
		dc2rgb( cvt, line );
		blank( cvt, 0, 4 );		//blank first 4 pixels
		blank( cvt, cvt->Width - 2, 2 );	//blank last 2 pixels
	} else {
		blank( cvt, 0, cvt->Width );	//blank full line (signature)
	}

	cvt->LineNum++;
}

/*	Check for DCTV signature.
	Sinature typically is in highest plane.
	Has 32 bytes data, so min width of image is 32*8=256 pixels.
	Max of depth for DCTV image is 4, but dctv.lib allow to 8.
	( planes > 4 must be cleared ).
*/
BOOL CheckDCTV( struct BitMap *bmp ) {

	UBYTE	sign[] = { 0xD5,0xAB,0x57,0xAF,0x5F,0xBF,0x7F,0xFF };
	UBYTE	buf[32], *plane;
	WORD	np, bpr, i, j, k, d0, d1, d2;

	np = bmp->Depth;
	bpr = bmp->BytesPerRow;

	if (( bpr < 32 )||( np > 4 ))
		return( FALSE );

	while ( np>0 ) {
		np--;

		// find first nonzero byte
		plane = bmp->Planes[np];
		k = bpr - 31;
		while (( *plane == 0 )&&( k != 0 )) {
			plane++;
			k--;
		}
		if ( k == 0 ) continue;

		// find nonzero hi bit
		d0 = *plane;
		k = 7;
		while ( (d0 & 0x80) == 0 ) {	//d0 nonzero value
		 	d0 <<= 1;
			k -= 1;
		}

		// generate signature
		d1 = sign[k];
		for ( i=0; i<32; i++ ) {
			d2 = 0;
			for ( j=0; j<8; j++ ) {
				d0 = ( d1 & 0xC3 ) + 0x41;
				d0 = ( d0 & 0x82 ) + 0x7E;
				d0 = ( d0 >> 7 ) & 1;	//test bit 7
				d1 = d1 + d1 + d0;
				d2 = d2 + d2 + 1 - d0;
			}
			buf[i] = d2;
		}
		if ( k == 7 )
			buf[31] &= 0xFE;

		// compare signatures
		for ( i=0; i<31; i++ ) {
			d0 = *plane++;
			d1 = buf[i];
			if ( d0 != d1 )
				return( FALSE );
		}
		return( TRUE );
	}
	return( FALSE );
}

/*	This function convert 12-bit Amiga palette
	to special DCTV values (Digital RGBI).
	Only 4 bits of 12 are used.
	Standard palettes are:
	for 4 planes (G=1,B=2,R=4,I=8)
	0x000,0x786,0x778,0x788,0x876,0x886,0x878,0x888 (-,G ,B ,GB ,R ,RG ,RB ,RGB )
	0x001,0x787,0x779,0x789,0x877,0x887,0x879,0x889 (I,GI,BI,GBI,RI,RGI,RBI,RGBI)
	for 3 planes (B=1,R=2,I=4)
	0x000,0x778,0x876,0x878 (-,B ,R ,RB ) 0,2,4,6
	0x001,0x779,0x877,0x879 (I,BI,RI,RBI) 8,A,C,E
	2 planes
	0x00e,0x40f,0xf0e,0xf0f (B,BI,RB,RBI) 2,A,6,E
	0x000,0x00f,0x80e,0xc0f

*/
void SetmapDCTV( struct DCTVCvtHandle *cvt, UWORD *cmap ) {

	UBYTE	cnt, val, *pal;
	UWORD	col;

	cvt->ColorTable = cmap;
	pal = cvt->Palette;
	cnt = cvt->NColors;

	while ( cnt > 0 ) {
		col = *cmap++;
		val = 0;
		if ( col & 1)		val = 64;	// DI
		if ( col & 0x800)	val |= 16;
		if ( col & 8)		val |= 4;
		if ( col & 0x80)	val |= 1;
		*pal++ = val;
		cnt--;
	}
}

/*	Allocate structure and some buffers for handle conversion.
	For free use FreeVec( cvt )
*/
struct DCTVCvtHandle* AllocDCTV( struct BitMap *bmp, UWORD lace) {

	struct DCTVCvtHandle	*cvt;
	UWORD	sw, sh, np, fields;
	WORD	i, sw15;
	UBYTE	*buf1, *buf2;

	if ( !bmp )
		return( NULL );

	sw = bmp->BytesPerRow << 3;
	sh = bmp->Rows;
	np = bmp->Depth;
	lace &= 1;	// 1=lace, 0=nonlace
	fields = lace + 1;

	if (( sw < 256 )||( sh < ( 2 * fields ))||( np > 4 ))
		return( NULL );

	if ( cvt = AllocVec( sizeof(struct DCTVCvtHandle) + ( sw << 4 ), MEMF_CLEAR )) {
		cvt->BitMap = bmp;
		cvt->Width = sw;
		cvt->Height = sh;
		cvt->NColors = 1 << np;
		cvt->Lace = lace;

		cvt->Red = (UBYTE *) cvt + sizeof(struct DCTVCvtHandle);
		cvt->Green = cvt->Red + sw;
		cvt->Blue = cvt->Green + sw;
		cvt->Chunky = cvt->Blue + sw;
		buf1 = buf2 = cvt->Chunky + sw;		// first field

		for( i=0; i<sw; i++ )
			*buf2++ = 0x40;	// luma = 0

		sw15 = sw >> 1;
		sw15 += sw;	// 1.5*sw

		buf2 = buf1 + ( sw15 << 2 );	// second field

		CopyMem( buf1, buf1 + sw15, sw );	//1 line luma copied
		CopyMem( buf1, buf1 + ( sw15 << 1 ), sw15 << 1 );	// 2 lines copied
		CopyMem( buf1, buf2, sw15 << 2 );	// 4 lines copied

		for( i=0; i<4; i++ ) {
			cvt->FBuf1[i] = buf1 + sw15 * i;
			cvt->FBuf2[i] = buf2 + sw15 * i;
		}
	}
	return( cvt );
}
