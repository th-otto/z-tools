#include "ilbm.h"
#include "dctv.h"

char *vers = "$VER: dctv 1.0 by Cholok";
char *usage = "Usage: dctv dctvfile iff24file";

int CXBRK(void) { return(0); }		/* Disable SASC CTRL/C handling */
int chkabort(void) { return(0); }	/* Indeed */

LONG Convert(void);
struct IFFHandle *OpenOutfile(void);
BOOL WriteRGB(struct IFFHandle *iff24, struct DCTVCvtHandle *cvt);
BOOL WriteChunkyLine(struct IFFHandle *iff,UBYTE *chunks,int width);
void ConvertPlane(UBYTE planemask, UBYTE *line, int width);
void CloseOutfile(struct IFFHandle *iff24);
void bye(UBYTE *s, int e);

extern struct ExecBase	*SysBase;

struct Library *IFFParseBase = NULL;
struct ILBMInfo ilbm = {0};

LONG error = NULL;
UBYTE *infile = NULL;
UBYTE *outfile = NULL;

UWORD *plane = NULL;
BYTE *compressed = NULL;

void printifferr( LONG err ) {
	if ( err < 0 ) {
		switch( err ) {
			case IFFERR_NOTIFF:
				puts("Not an IFF file");
				break;
			case IFFERR_READ:
			case IFFERR_WRITE:
			case IFFERR_SEEK:
				puts("Read/Write/Seek error");
				break;
			case IFFERR_MANGLED:
			case IFFERR_SYNTAX:
			case IFFERR_NOSCOPE:
				puts("Corrupt IFF file");
				break;
			case IFFERR_NOMEM:
				puts("Out of memory");
				break;
			default:
				puts("Unknown iffparse error");
		}
	}
	return;
}

void main( int argc, char **argv ) {

	if ( ( argc<3 ) || (argv[argc-1][0]=='?') )
		bye( usage,RETURN_OK );
	
	infile = argv[1];
	outfile = argv[2];
	
	if ( SysBase->LibNode.lib_Version < 36 )
		bye( "Kickstart V36 at least required",RETURN_FAIL );

	if ( !( SysBase->AttnFlags & AFF_68020 ))
		bye( "CPU020 at least required",RETURN_FAIL );

	if ( !( IFFParseBase = OpenLibrary("iffparse.library",0) ))
		bye("Unable to open iffparse.library",RETURN_FAIL);
	
	if( !( ilbm.iff = AllocIFF()))
		bye( "Out of memory",RETURN_FAIL );
	
	if ( error = loadilbm( &ilbm, infile )) {
		printifferr( error );
		unloadilbm( &ilbm );
		bye( "Unable to load ilbm",RETURN_FAIL );
	}

	error = Convert();

	unloadilbm( &ilbm );
	bye( "",error );
}

/* Convert to 24 bit */
LONG Convert() {
	struct IFFHandle *iff24 = NULL;
	struct DCTVCvtHandle *cvt = NULL;
	WORD	i;
	char	*errstr1 = "Error writing file";

	if ( !( CheckDCTV( &ilbm.bitmap )) ) {
		puts( "Not a DCTV picture" );
		goto abort;
	}

	cvt = AllocDCTV( &ilbm.bitmap, (ilbm.camg & LACE) ? 1 : 0 );
	plane = AllocVec( ilbm.bitmap.BytesPerRow, MEMF_ANY );
	compressed = AllocVec( MaxPackedSize( ilbm.bitmap.BytesPerRow ), MEMF_ANY );

	if (( !cvt )||( !plane )||( !compressed )) {
		puts( "Out of memory" );
		error = RETURN_FAIL;
		goto abort;
	}

	if ( !( iff24 = OpenOutfile()) ) {
		puts( "Unable to open output file" );
		error = RETURN_FAIL;
		goto abort;
	}

	SetmapDCTV( cvt, ilbm.colortable );

	for ( i=0; i<cvt->Height; i++ ) {

		if ( SetSignal( 0,SIGBREAKF_CTRL_C ) & SIGBREAKF_CTRL_C ) {
			puts("**BREAK");
			error = RETURN_WARN;
			goto abort;
		}

		ConvertDCTVLine( cvt );

		if ( !(WriteRGB( iff24, cvt ))) {
			puts( errstr1 );
			error = RETURN_FAIL;
			goto abort;
		}
	}

	if( PopChunk(iff24) ) {	/* Close BODY chunk */
		puts( errstr1 );
		error = RETURN_FAIL;
		goto abort;
	}
	
	if ( PopChunk(iff24) ) {	/* Close FORM */
		puts( errstr1 );
		error = RETURN_FAIL;
		goto abort;
	}
	
	error = RETURN_OK;

abort:
	if ( compressed )
		FreeVec( compressed );
	if (plane)
		FreeVec( plane );
	if (cvt)
		FreeVec( cvt );
	CloseOutfile( iff24 );
	return error;
}

/* Open 24-bit IFF */
struct IFFHandle * OpenOutfile() {
	struct IFFHandle *iff;
	BitMapHeader bmhd;
	
	if (!( iff = AllocIFF() ))
		return NULL;
	if (!( iff->iff_Stream = Open( outfile, MODE_NEWFILE )))
		goto abortopen;
	InitIFFasDOS( iff );
	if ( OpenIFF( iff, IFFF_WRITE ))
		goto abortopen;
	
	/* Write header */
	if ( PushChunk( iff, ID_ILBM, ID_FORM, IFFSIZE_UNKNOWN ))
		goto abortopen;
	
	/* Write BMHD */
	if ( PushChunk( iff, ID_ILBM, ID_BMHD, sizeof(BitMapHeader) ))
		goto abortopen;

	/* Set BMHD values */
	CopyMem(&ilbm.bmhd,&bmhd,sizeof(bmhd));
	bmhd.nPlanes=24;
	bmhd.masking=mskNone;
	bmhd.compression=cmpByteRun1;
	bmhd.flags=0;
	
	if (WriteChunkBytes(iff,&bmhd,sizeof(bmhd)) != sizeof(bmhd))
		goto abortopen;
	if (PopChunk(iff))
		goto abortopen;
	
	/* Write BODY header */
	if (PushChunk(iff,ID_ILBM,ID_BODY,IFFSIZE_UNKNOWN))
		goto abortopen;

	return iff;

abortopen:
	CloseOutfile( iff );
	return NULL;
}
	
void CloseOutfile( struct IFFHandle *iff ) {
	if( iff ) {
		CloseIFF( iff );
		if ( iff->iff_Stream )
			Close( iff->iff_Stream );
		FreeIFF( iff );
	}
}
	
BOOL WriteRGB(struct IFFHandle *iff, struct DCTVCvtHandle *cvt) {
	if (!(WriteChunkyLine(iff,cvt->Red,cvt->Width)!=cvt->Width))
	  return FALSE;
	if (!(WriteChunkyLine(iff,cvt->Green,cvt->Width)!=cvt->Width))
	  return FALSE;
	if (!(WriteChunkyLine(iff,cvt->Blue,cvt->Width)!=cvt->Width))
	  return FALSE;
	return TRUE;
}

/* Write one line of a primary color */
BOOL WriteChunkyLine(struct IFFHandle *iff,UBYTE *chunks,int width) {
	UBYTE	i;
	LONG	length;
	/* Pointers are incremented by packrow() so we use a copy */
	BYTE	*temp_plane;
	BYTE	*temp_comp;
	
	/* Ends when i overflows */
	for (i=1; i!=0; i+=i) {
		temp_plane=(BYTE *)plane;
		temp_comp=compressed;
		ConvertPlane(i, chunks, width);
		length=packrow(&temp_plane,&temp_comp,(LONG)ilbm.bitmap.BytesPerRow);
		if (WriteChunkBytes(iff,compressed,length)!=length)
	  		return FALSE;
	}
	return TRUE;
}

void ConvertPlane(UBYTE planemask, UBYTE *line, int width) {
	int i,j,end;
	UWORD currbit;
	
	for (i=0,j=0; i<width; j++) {
		for (plane[j]=0,currbit=0x8000,end=min(width,i+16); i<end; i++,currbit=currbit>>1) {
			if (line[i]&planemask)
				plane[j] |= currbit;
		}
	}
}

void bye( UBYTE *s, int e) {
	if ( s && (*s))
		printf("%s\n\n",s);
	if (ilbm.iff)
		FreeIFF(ilbm.iff);
	if (IFFParseBase)
		CloseLibrary(IFFParseBase);
	exit(e);
}
